
# Contributing to Grid Backtester

We welcome contributions!

## How to Contribute

1. Fork the repository
2. Create a new branch (`git checkout -b feature-xyz`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature-xyz`)
5. Open a pull request

## Code Guidelines

- Use PEP8 for Python
- Document new functions clearly
- Add tests or examples if possible

Thank you!
